//# The symbol # designates Pocket Pew notes or Pocket Pew custom code
//# Modified Open Source Code Packaged with ADA Bluefruit for testing/development purposes

package com.laserhawk.pocketpewportablelasertag.app.shortener;

import android.os.AsyncTask;

public class ShortenerAsyncTask extends AsyncTask<String, Void, String> {

    public interface ShortenerListener {
        void onUriShortened(String shortenedUri);
    }

    private ShortenerListener mListener;

    public ShortenerAsyncTask(ShortenerListener listener) {
        mListener = listener;
    }

    @Override
    protected String doInBackground(String... urls) {

        // Default implementation: no shortening
        String originalUrl = urls[0];

        return originalUrl;
    }

    protected void onPostExecute(String result) {
        if (mListener != null) {
            mListener.onUriShortened(result);
        }
    }
}
