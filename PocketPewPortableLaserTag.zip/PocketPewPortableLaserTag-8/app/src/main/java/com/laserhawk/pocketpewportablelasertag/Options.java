package com.laserhawk.pocketpewportablelasertag;
//# The symbol # designates Pocket Pew notes or Pocket Pew custom code
//# Custom Pocket Pew Options Menu

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.laserhawk.pocketpewportablelasertag.app.UartActivity;

public class
Options extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);

        Button b = (Button) findViewById(R.id.btnContinue2);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Options.this, UartActivity.class));
            }
        });

        Button b2 = (Button) findViewById(R.id.btnReconnect);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Options.this, Connect.class));
            }
        });

    }
}
