//# The symbol # designates Pocket Pew notes or Pocket Pew custom code
//# Custom Pocket Pew Splash Screen
package com.laserhawk.pocketpewportablelasertag;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class Splash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        setContentView(R.layout.activity_splash);
        TimerTask task= new TimerTask() {
            @Override
            public void run() {
                finish();
                startActivity(new Intent(Splash.this, MainActivity.class));
            }
        };
        Timer opening = new Timer(); //# Sets timer for starting app.
        opening.schedule(task, 5000); //# At end of timer, app starts.
    }
}
