//# The symbol # designates Pocket Pew notes or Pocket Pew custom code
//# Custom Pocket Pew page for instructions.
package com.laserhawk.pocketpewportablelasertag;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b = (Button) findViewById(R.id.btnBegin);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Connect.class));
            }
        });

    }


    @Override
    public void onBackPressed() {
    }
}
